<?php

namespace App\Repository;

use App\Entity\FootEquipement;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @method FootEquipement|null find($id, $lockMode = null, $lockVersion = null)
 * @method FootEquipement|null findOneBy(array $criteria, array $orderBy = null)
 * @method FootEquipement[]    findAll()
 * @method FootEquipement[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class FootEquipementRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, FootEquipement::class);
    }

    // /**
    //  * @return FootEquipement[] Returns an array of FootEquipement objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('f')
            ->andWhere('f.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('f.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    /*
    public function findOneBySomeField($value): ?FootEquipement
    {
        return $this->createQueryBuilder('f')
            ->andWhere('f.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */
}
